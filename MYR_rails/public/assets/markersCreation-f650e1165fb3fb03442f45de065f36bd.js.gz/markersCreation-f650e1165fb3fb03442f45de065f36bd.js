$(document).ready(function(){
	
	initializeMap();
	initialScroll();
	addingBoil();

});
